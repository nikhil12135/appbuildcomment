from flask import Flask
from selenium.webdriver import Keys

app = Flask(__name__)


@app.route('/comment/<fi_no>')
def hello_world(fi_no):  # put application's code here
    import time
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    chrome_options = Options()
    chrome_options.add_experimental_option("detach", True)
    driver = webdriver.Chrome(options=chrome_options)
    url = "https://mdevtool.netlify.app/"
    fi=fi_no
    driver.get(url)

    driver.find_element(By.XPATH, '//*[@id="subj"]').send_keys(fi_no)
    time.sleep(0.2)
    driver.find_element(By.XPATH, '//*[@id="theForm"]/button').click()

    div_element = driver.find_element(By.XPATH, '//span[contains(text(), "-testflight")]')

    # Click on the div element
    div_element.click()

    time.sleep(0.5)

    # Build URL
    build_url = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[1]/tbody/tr[4]/td[2]').text
    print("Env URL : " + build_url)
    env_url="Env URL : " + build_url
    # PROFILE
    print("Profile : Testflight")
    profile="Profile : Testflight"
    print("Android :")
    android="Android :"
    # IMAGE SET

    #print("Image set:" + image_sett)
    #img="Image set:" + image_sett
    # MDEV URL
    url1 = driver.current_url
    print("Mdev Link : " + url1)
    mdev="Mdev Link : " + url1
    # Build Time
    build_time = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[1]/tbody/tr[3]/td[2]').text
    print("Build Time : " + build_time)
    b_time="Build Time : " + build_time
    # Build Version
    build_ver = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[1]/tbody/tr[2]/td[2]').text
    print("Build Version : " + build_ver)
    verr="Build Version : " + build_ver
    # IOS
    driver.find_element(By.XPATH, '//*[@id="switch"]/div[2]').click()
    time.sleep(0.5)
    # IOS
    print("iOS :")
    ios="iOS :"
    print("App Link : In Review")
    applink="App Link : In Review"
    # Build Time
    iod_build_time = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[1]/tbody/tr[3]/td[2]').text
    print("Build Time : " + iod_build_time)
    b_tym="Build Time :  "+ iod_build_time
    # Build Version
    offset = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[2]/tbody/tr[4]/td[2]').text
    build_version = driver.find_element(By.XPATH, '//*[@id="content"]/div[2]/div[1]/table[1]/tbody/tr[2]/td[2]').text
    print("Build Version : " + build_version + "(" + offset + ")")
    build_verry="Build Version : " + build_version + "(" + offset + ")"
    apple_agg="Apple Agreements: Issue found has attached the screenshot in the Chatter feed "
    google_agg="Google Data Safety Form: Issue found has attached the screenshot in the Chatter feed"

    apple_agg2="Apple Agreements: No Issue found"
    google_agg22="Google Data Safety Form: No Issue found"
    driver.close()
    my_list =[ env_url, profile, android, mdev, b_time, verr, ios, applink, b_tym, build_verry, apple_agg, google_agg, apple_agg2, google_agg22]
    return my_list



if __name__ == '__main__':
    app.run()
